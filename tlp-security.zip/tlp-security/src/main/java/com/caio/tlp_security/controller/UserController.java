package com.caio.tlp_security.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.caio.tlp_security.modelo.Role;
import com.caio.tlp_security.repository.RoleRepository;
import com.caio.tlp_security.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.CurrentSecurityContext;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.caio.tlp_security.modelo.User;

@Controller
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private RoleRepository roleRepository;
	
	// início spring security (c-curte)
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	
	private boolean hasAuthorization(User user, String role) {
		for (Role pp : user.getRoles()) {
			if (pp.getRole().equals(role)) {
				return true;
			}
	    }
		return false;
	}
	
	@RequestMapping("/index")
	public String index(@CurrentSecurityContext(expression="authentication.name") String login, Model model) {
		User user = userRepository.findByLogin(login);

		String redirectURL = "";
		if (hasAuthorization(user, "ADMIN")) {
			redirectURL = "/auth/admin/admin-index";
        } else if (hasAuthorization(user, "USER")) {
            redirectURL = "/auth/user/user-index";
        } else if (hasAuthorization(user, "LIBRARIAN")) {
            redirectURL = "/auth/libra/libra-index";
        }
		
		model.addAttribute("usuarioLogado", user);
		return redirectURL;		
	}
	// fim spring security (c-curte)

	@GetMapping("/novo")
	public String addUser(Model model) {
		model.addAttribute("user", new User());
		return "/public-create-user";
	}
	
	@PostMapping("/salvar")
	public String saveUser(@Valid User user, BindingResult result,
								RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return "/public-create-user";
		}
		
		//Busca o role básico de usuário
		Role role = roleRepository.findByRole("USER");
		List<Role> roles = new ArrayList<Role>();
		roles.add(role);
		user.setRoles(roles); // associa o role de USER ao usuário
		
		String senhaCriptografada = passwordEncoder.encode(user.getPassword());
		user.setPassword(senhaCriptografada);

		//user.setAtivo(true); /* Colocando usuário como ativo de default no banco pra testar login */
		
		userRepository.save(user);
		attributes.addFlashAttribute("mensagem", "Usuário salvo com sucesso!");
		return "redirect:/user/novo";
	}
	
	@RequestMapping("/admin/listar")
	public String listarUsuario(@CurrentSecurityContext(expression="authentication.name") String login, Model model) {
		User user = userRepository.findByLogin(login);

		model.addAttribute("usuarios", userRepository.findAll());
		model.addAttribute("usuarioLogado", user);
		return "/auth/admin/admin-listar-user";
	}
	
	@GetMapping("/admin/apagar/{id}")
	public String deleteUser(@PathVariable("id") long id, Model model) {
		User user = userRepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("Id inválido:" + id));
		userRepository.delete(user);
	    return "redirect:/user/admin/listar";
	}
	
	
	@GetMapping("/editar/{id}")
	public String editarUsuario(@CurrentSecurityContext(expression="authentication.name") String login, @PathVariable("id") long id, Model model) {
		Optional<User> usuarioVelho = userRepository.findById(id);
		if (!usuarioVelho.isPresent()) {
            throw new IllegalArgumentException("Usuário inválido:" + id);
        } 

		User userLogin = userRepository.findByLogin(login);

		User user = usuarioVelho.get();
	    model.addAttribute("user", user);
		model.addAttribute("usuarioLogado", userLogin);
	    return "/auth/user/user-alterar-user";
	}
	
	@PostMapping("/edit/{id}")
	public String editUser(@PathVariable("id") long id, @Valid User user, BindingResult result, RedirectAttributes attributes) {
	    if (result.hasErrors()) {
	    	user.setId(id);
	        return "/auth/user/user-alt-user";
	    }	

		Optional<User> oldUser = userRepository.findById(id);
		user.setActive(oldUser.get().isActive());
		user.setRoles(oldUser.get().getRoles());

	    userRepository.save(user);
	    attributes.addFlashAttribute("msg", "Usuário alterado com sucesso!");

		return "redirect:/user/new";
	}
	
	@GetMapping("/editRole/{id}")
	public String selectRole(@CurrentSecurityContext(expression="authentication.name") String login, @PathVariable("id") long id, Model model) {
		Optional<User> oldUser = userRepository.findById(id);
		if (!oldUser.isPresent()) {
            throw new IllegalArgumentException("Usuário inválido:" + id);
        } 
		User userLogin = userRepository.findByLogin(login);
		User user = oldUser.get();
		model.addAttribute("listRoles", roleRepository.findAll());
	    model.addAttribute("user", user);
		model.addAttribute("loggedUser", userLogin);
	    return "/auth/admin/admin-edit-role-user";
	}
	
	@PostMapping("/editRole/{id}")
	public String assignRole(@PathVariable("id") long idUser,
								@RequestParam(value = "pps", required=false) int[] pps, 
								User user,
								RedirectAttributes attributes) {
		if (pps == null) {
			user.setId(idUser);
			attributes.addFlashAttribute("msg", "Pelo menos um papel deve ser informado");
			return "redirect:/user/editRole/"+idUser;
		} else {
			List<Role> roles = new ArrayList<Role>();
			for (int i = 0; i < pps.length; i++) {
				long idRole = pps[i];
				Optional<Role> roleOptional = roleRepository.findById(idRole);
				if (roleOptional.isPresent()) {
					Role role = roleOptional.get();
					roles.add(role);
		        }
			}
			Optional<User> userOptional = userRepository.findById(idUser);
			if (userOptional.isPresent()) {
				User usr = userOptional.get();
				usr.setRoles(roles);
				usr.setActive(user.isActive());
				userRepository.save(usr);
	        }			
		}		
	    return "redirect:/user/admin/list";
	}
	
}
