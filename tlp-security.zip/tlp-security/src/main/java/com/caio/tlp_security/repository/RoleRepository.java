package com.caio.tlp_security.repository;

import com.caio.tlp_security.modelo.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Long> {
	Role findByRole(String role);
}
