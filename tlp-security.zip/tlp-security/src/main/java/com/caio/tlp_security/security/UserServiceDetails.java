package com.caio.tlp_security.security;

import java.util.Set;
import java.util.HashSet;
 
import javax.transaction.Transactional;

import com.caio.tlp_security.modelo.User;
import com.caio.tlp_security.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.caio.tlp_security.modelo.Role;

@Service
@Transactional
public class UserServiceDetails implements UserDetailsService {
	
	// Injeta pelo construtor
	private UserRepository userRepository;
	
	public UserServiceDetails(UserRepository userRepository) {
		this.userRepository = userRepository;
	}
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userRepository.findByLogin(username);
			
		if(user != null && user.isActive()) {
			Set<GrantedAuthority> roles = getRoles(user);
			org.springframework.security.core.userdetails.User usuario = new org.springframework.security.core.userdetails.User(user.getLogin(), user.getPassword(), roles);
			return usuario;
		} else {
			throw new UsernameNotFoundException("Usuário não encontrado");
		}
	}
	
	private Set<GrantedAuthority> getRoles(User user){
		Set<GrantedAuthority> roles = new HashSet<GrantedAuthority>();
		for(Role role : user.getRoles()) {
			GrantedAuthority pp = new SimpleGrantedAuthority(role.getRole());
			roles.add(pp);
		}
		return roles;
	}
}
