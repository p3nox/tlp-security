package com.caio.tlp_security.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	
	@RequestMapping("/") 
	public String index(Model model) {
		model.addAttribute("msnBemVindo", "Biblioteca");
		return "public-index";
	}

	@RequestMapping("/login")
	public String login() {
		return "login";
	}
}
