package com.caio.tlp_security.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.caio.tlp_security.modelo.User;

public interface UserRepository extends JpaRepository<User, Long> {
	User findByLogin(String login);
}
